package com.example.joseramonninomontana.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class Main2Activity extends AppCompatActivity {
    ImageButton siguiente2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        siguiente2=(ImageButton)findViewById(R.id.PlayButton2)


        siguiente2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent siguiente = Intent(Main2Activity.this, MainActivity.class);
                startActivity(siguiente);

            }

        }
    }

}

